Name : Gayatri Santosh Badgujar
Assignment 1 : Spark Coding test(pyspark uisng Zeppelin


